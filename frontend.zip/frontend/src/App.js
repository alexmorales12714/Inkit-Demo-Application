import React from "react";
import Documents from "./Documents";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Documents />
      </header>
    </div>
  );
}

export default App;
